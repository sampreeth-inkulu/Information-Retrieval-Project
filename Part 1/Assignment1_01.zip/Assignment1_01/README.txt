Group 01
# Python 3.7.4
Libraries used: os, re, sys, pickle, string, time, nltk

Specific info:

Documents are sorted in a custom manner.
Files within smaller(alphabetically) directory are smaller than those in larger directories.
Files in same directory are sorted as strings(alphabetically).

Case folding was done to the tokens

index is a dictionary mapping each term to a list. Each list consists of document frequency and the term's posting list.
